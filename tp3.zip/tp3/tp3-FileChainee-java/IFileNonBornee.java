public interface IFileNonBornee<E> extends IFile<E> {
	
	public void add(E e);
	
}
