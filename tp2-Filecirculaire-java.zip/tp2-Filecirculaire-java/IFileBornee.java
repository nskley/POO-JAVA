
public interface IFileBornee<E> extends IFile<E> {
    public boolean IsFull();
    public int getCapacity();
}